classdef programState
    properties
        currentTime;
        tof_current;
        previousTime;
        N;
        initial_DeltaV;
        failedOrbits;
        testedOrbits;
        isRunning;
    end
end

